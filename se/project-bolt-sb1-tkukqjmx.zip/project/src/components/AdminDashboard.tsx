import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, Trash2, ChevronDown, ChevronUp } from 'lucide-react';

interface FeedbackData {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [feedbacks, setFeedbacks] = useState<FeedbackData[]>([]);
  const [sortBy, setSortBy] = useState<'date' | 'rating'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    // Check if user is admin (you might want to implement proper admin authentication)
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
      navigate('/signin');
      return;
    }

    // Load feedbacks from localStorage
    const storedFeedbacks = JSON.parse(localStorage.getItem('feedbacks') || '[]');
    setFeedbacks(storedFeedbacks);
  }, [navigate]);

  const handleSort = (criteria: 'date' | 'rating') => {
    if (sortBy === criteria) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(criteria);
      setSortOrder('desc');
    }
  };

  const sortedFeedbacks = [...feedbacks].sort((a, b) => {
    if (sortBy === 'date') {
      return sortOrder === 'asc'
        ? new Date(a.date).getTime() - new Date(b.date).getTime()
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    } else {
      return sortOrder === 'asc'
        ? a.rating - b.rating
        : b.rating - a.rating;
    }
  });

  const handleDelete = (id: string) => {
    const updatedFeedbacks = feedbacks.filter(feedback => feedback.id !== id);
    setFeedbacks(updatedFeedbacks);
    localStorage.setItem('feedbacks', JSON.stringify(updatedFeedbacks));
  };

  const averageRating = feedbacks.length
    ? (feedbacks.reduce((sum, feedback) => sum + feedback.rating, 0) / feedbacks.length).toFixed(1)
    : '0.0';

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="bg-white rounded-3xl shadow-lg overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-[#7CC5E3] p-4 rounded-lg text-white">
              <h3 className="text-lg font-semibold">Total Feedback</h3>
              <p className="text-2xl">{feedbacks.length}</p>
            </div>
            <div className="bg-[#7CC5E3] p-4 rounded-lg text-white">
              <h3 className="text-lg font-semibold">Average Rating</h3>
              <p className="text-2xl">{averageRating}/5</p>
            </div>
            <div className="bg-[#7CC5E3] p-4 rounded-lg text-white">
              <h3 className="text-lg font-semibold">Latest Feedback</h3>
              <p className="text-2xl">{feedbacks.length ? new Date(feedbacks[0].date).toLocaleDateString() : 'No feedback'}</p>
            </div>
          </div>

          <div className="bg-white rounded-lg overflow-hidden">
            <div className="flex justify-between items-center mb-4">
              <button
                onClick={() => handleSort('date')}
                className="flex items-center gap-1 px-4 py-2 hover:bg-gray-100 rounded"
              >
                Date
                {sortBy === 'date' && (
                  sortOrder === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={() => handleSort('rating')}
                className="flex items-center gap-1 px-4 py-2 hover:bg-gray-100 rounded"
              >
                Rating
                {sortBy === 'rating' && (
                  sortOrder === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                )}
              </button>
            </div>

            <div className="space-y-4">
              {sortedFeedbacks.map((feedback) => (
                <div key={feedback.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold">{feedback.userName}</h3>
                      <p className="text-sm text-gray-500">{new Date(feedback.date).toLocaleString()}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {Array.from({ length: 5 }).map((_, index) => (
                          <Star
                            key={index}
                            className={`w-5 h-5 ${
                              index < feedback.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <button
                        onClick={() => handleDelete(feedback.id)}
                        className="text-red-500 hover:text-red-600"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-700">{feedback.comment}</p>
                </div>
              ))}

              {feedbacks.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No feedback available
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;