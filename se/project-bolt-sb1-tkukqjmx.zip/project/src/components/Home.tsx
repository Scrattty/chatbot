import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Brain } from 'lucide-react';

const Home = () => {
  const [text, setText] = useState('');
  const fullText = "Hello, I'm SAMI your personal mental wellness companion";
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setText(fullText.slice(0, currentIndex + 1));
        setCurrentIndex(currentIndex + 1);
      }, 50);
      return () => clearTimeout(timeout);
    }
  }, [currentIndex]);

  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="bg-[#7CC5E3] rounded-3xl p-12">
        <div className="flex justify-between items-center">
          <div className="max-w-xl">
            <span className="inline-block bg-white/20 px-4 py-1 rounded-full text-white mb-6">
              #flexiblesolutions
            </span>
            <h1 className="text-4xl font-bold text-white mb-6">
              {text}
              <span className="animate-pulse">|</span>
            </h1>
            <p className={`text-white/90 mb-8 transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
              Your dedicated AI companion for mental wellness support. Experience personalized
              conversations, track your emotional well-being, and access helpful resources
              whenever you need them.
            </p>
            <Link
              to="/chat"
              className={`inline-flex items-center bg-white text-black px-6 py-3 rounded-full hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
            >
              Chat With SAMI
              <span className="ml-2">→</span>
            </Link>
          </div>
          <div className={`relative transition-transform duration-1000 ${isVisible ? 'translate-x-0' : 'translate-x-24'}`}>
            <div className="w-80 h-80 bg-black rounded-3xl flex items-center justify-center">
              <div className="flex flex-col items-center">
                <div className="relative animate-pulse">
                  <div className="w-40 h-40 border-4 border-[#7CC5E3] rounded-full" />
                  <Brain className="w-32 h-32 text-[#7CC5E3] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                </div>
                <div className="mt-4 flex">
                  <div className="w-16 h-1 bg-[#7CC5E3] rounded-full mx-1" />
                  <div className="w-16 h-1 bg-[#7CC5E3] rounded-full mx-1" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;