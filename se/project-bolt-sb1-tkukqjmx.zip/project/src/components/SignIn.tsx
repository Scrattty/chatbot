import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Brain } from 'lucide-react';

const SignIn = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (error) setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for admin credentials
    if (formData.email === 'admin@sami.com' && formData.password === 'admin123') {
      const adminUser = {
        email: formData.email,
        fullname: 'Admin',
        isAdmin: true
      };
      localStorage.setItem('currentUser', JSON.stringify(adminUser));
      setShowSuccess(true);
      setTimeout(() => {
        navigate('/admin');
      }, 2000);
      return;
    }

    // Regular user authentication
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find((u: any) => u.email === formData.email);

    if (user && user.password === formData.password) {
      setShowSuccess(true);
      setError('');
      localStorage.setItem('currentUser', JSON.stringify(user));
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } else {
      setError('Wrong password or Email');
      setShowSuccess(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 flex justify-center items-start">
      {showSuccess && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg">
          Login successful! Redirecting...
        </div>
      )}
      <div className="flex w-full max-w-4xl">
        <div className="bg-[#7CC5E3] w-1/2 p-12 rounded-l-3xl flex flex-col items-center justify-center">
          <h1 className="text-4xl font-bold text-black mb-4">SAMI</h1>
          <p className="text-center text-black/80 mb-8">
            Your personal mental wellness companion
          </p>
          <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center">
            <div className="grid grid-cols-2 gap-2">
              <div className="w-8 h-8 bg-pink-300 rounded-tl-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-tr-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-bl-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-br-lg" />
            </div>
          </div>
        </div>
        <div className="bg-white w-1/2 p-12 rounded-r-3xl">
          <h2 className="text-2xl font-bold mb-4">Welcome Back</h2>
          <p className="text-gray-600 mb-8">
            Sign in to continue your mental wellness journey
          </p>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent ${
                  error ? 'border-red-500' : 'border-gray-300'
                }`}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent ${
                  error ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {error && (
                <p className="mt-2 text-sm text-red-600">
                  {error}
                </p>
              )}
            </div>
            <button
              type="submit"
              className="w-full bg-[#7CC5E3] text-white py-2 rounded-lg hover:bg-[#6BB4D2] transition-colors"
            >
              Sign in
            </button>
          </form>
          <p className="text-center text-sm text-gray-600 mt-6">
            <Link to="/" className="text-[#7CC5E3] hover:underline">
              Forgot Password
            </Link>
          </p>
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Don't have an account?{' '}
              <Link to="/signup" className="text-[#7CC5E3] hover:underline">
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;