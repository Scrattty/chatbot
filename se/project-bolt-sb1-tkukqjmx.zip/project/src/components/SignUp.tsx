import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Brain } from 'lucide-react';

const SignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullname: '',
    email: '',
    gender: '',
    birthdate: '',
    password: '',
    confirmPassword: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (error) setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    // Store user data in localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if email already exists
    if (users.some((user: any) => user.email === formData.email)) {
      setError('Email already exists');
      return;
    }

    // Add new user
    users.push({
      fullname: formData.fullname,
      email: formData.email,
      gender: formData.gender,
      birthdate: formData.birthdate,
      password: formData.password // In a real app, this should be hashed
    });
    
    localStorage.setItem('users', JSON.stringify(users));
    setShowSuccess(true);
    
    // Redirect to signin page after 2 seconds
    setTimeout(() => {
      navigate('/signin');
    }, 2000);
  };

  return (
    <div className="container mx-auto px-4 py-12 flex justify-center items-start">
      {showSuccess && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg">
          Account created successfully! Redirecting to login...
        </div>
      )}
      <div className="flex w-full max-w-4xl">
        <div className="bg-[#7CC5E3] w-1/2 p-12 rounded-l-3xl flex flex-col items-center justify-center">
          <h1 className="text-4xl font-bold text-black mb-4">SAMI</h1>
          <p className="text-center text-black/80 mb-8">
            Your personal mental wellness companion
          </p>
          <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center">
            <div className="grid grid-cols-2 gap-2">
              <div className="w-8 h-8 bg-pink-300 rounded-tl-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-tr-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-bl-lg" />
              <div className="w-8 h-8 bg-pink-300 rounded-br-lg" />
            </div>
          </div>
        </div>
        <div className="bg-white w-1/2 p-12 rounded-r-3xl">
          <h2 className="text-2xl font-bold mb-4">Start Your Wellness Journey</h2>
          <p className="text-gray-600 mb-8">
            Create an account to access personalized mental health support
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fullname
              </label>
              <input
                type="text"
                name="fullname"
                value={formData.fullname}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent ${
                  error.includes('Email') ? 'border-red-500' : 'border-gray-300'
                }`}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Gender
                </label>
                <input
                  type="text"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Birthdate
                </label>
                <input
                  type="date"
                  name="birthdate"
                  value={formData.birthdate}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent ${
                  error.includes('Passwords') ? 'border-red-500' : 'border-gray-300'
                }`}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confirm password
              </label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#7CC5E3] focus:border-transparent ${
                  error.includes('Passwords') ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {error && (
                <p className="mt-2 text-sm text-red-600">
                  {error}
                </p>
              )}
            </div>
            <div className="text-xs text-gray-600 space-y-2">
              <p>By signing up, you agree that:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>This is not a substitute for professional mental health treatment</li>
                <li>In case of emergency, please contact a healthcare provider or emergency services</li>
                <li>Your data will be stored locally on your device</li>
              </ul>
            </div>
            <button
              type="submit"
              className="w-full bg-[#7CC5E3] text-white py-2 rounded-lg hover:bg-[#6BB4D2] transition-colors"
            >
              Create Account
            </button>
          </form>
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/signin" className="text-[#7CC5E3] hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;