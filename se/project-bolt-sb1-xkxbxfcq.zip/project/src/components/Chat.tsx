import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Send, Smile, Mic } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface Conversation {
  id: string;
  userId: string;
  date: string;
  topic: string;
  messages: Message[];
}

const Chat = () => {
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastActivityTime, setLastActivityTime] = useState<Date>(new Date());
  const [mood, setMood] = useState<string>('');
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const chatAreaRef = useRef<HTMLDivElement>(null);
  const [isMoodRated, setIsMoodRated] = useState(false);

  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
      navigate('/signup');
      return;
    }

    // Check for existing conversation
    const savedConversation = localStorage.getItem('currentConversation');
    if (savedConversation) {
      const conversation = JSON.parse(savedConversation);
      // Convert string timestamps back to Date objects
      const parsedMessages = conversation.messages.map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.timestamp)
      }));
      setMessages(parsedMessages);
      setCurrentConversation({
        ...conversation,
        messages: parsedMessages
      });
      setIsMoodRated(true); // Set to true since we're continuing a conversation
      // Clear the temporary storage
      localStorage.removeItem('currentConversation');
    } else if (messages.length === 0) {
      const botMessage: Message = {
        id: crypto.randomUUID(),
        text: "Hello! How are you feeling today? (Please rate your mood from 1-10, where 1 is very low and 10 is excellent)",
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages([botMessage]);
    }

    // Scroll to bottom on load
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [navigate]);

  // Save conversation whenever messages change
  useEffect(() => {
    if (messages.length > 1) {
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      const allConversations = JSON.parse(localStorage.getItem('conversations') || '[]');
      
      const topic = messages.slice(0, 2).map(m => m.text).join(' ').substring(0, 50);
      
      const conversation: Conversation = {
        id: currentConversation?.id || crypto.randomUUID(),
        userId: currentUser.email,
        date: new Date().toISOString(),
        topic,
        messages
      };

      const otherConversations = allConversations.filter((conv: Conversation) => 
        conv.id !== conversation.id
      );
      
      localStorage.setItem('conversations', JSON.stringify([...otherConversations, conversation]));
      setCurrentConversation(conversation);
    }
  }, [messages]);

  // Save mood data when mood is rated
  useEffect(() => {
    if (mood && !isMoodRated) {
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      const moodHistory = JSON.parse(localStorage.getItem('moodHistory') || '[]');
      
      const newMoodEntry = {
        userId: currentUser.email,
        mood: parseInt(mood),
        date: new Date().toISOString(),
        note: messages[messages.length - 1]?.text || ''
      };

      moodHistory.push(newMoodEntry);
      localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
      setIsMoodRated(true);
    }
  }, [mood, messages, isMoodRated]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    setLastActivityTime(new Date());

    const userMessage: Message = {
      id: crypto.randomUUID(),
      text: message,
      sender: 'user',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);

    // Handle mood rating
    if (!isMoodRated && messages.length === 1 && !isNaN(Number(message)) && Number(message) >= 1 && Number(message) <= 10) {
      setMood(message);
      const response = `Thank you for sharing. I see your mood is ${message}/10. `;
      const followUp = Number(message) < 5 
        ? "I'm here to support you. Would you like to talk about what's bothering you?"
        : "That's great! Would you like to share what's making you feel good today?";

      setTimeout(() => {
        const botMessage: Message = {
          id: crypto.randomUUID(),
          text: response + followUp,
          sender: 'bot',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botMessage]);
      }, 1000);
    } else {
      // Generate bot response based on user's message and conversation context
      setTimeout(() => {
        let botResponse = "I understand. Please tell me more about how you're feeling.";
        
        // Check previous messages for context
        const recentMessages = messages.slice(-4);
        const context = recentMessages.map(m => m.text.toLowerCase()).join(' ');
        
        // Enhanced contextual responses
        if (context.includes('work') || context.includes('job')) {
          if (context.includes('stress') || context.includes('pressure')) {
            botResponse = "Work-related stress can be challenging. What specific aspects of your job are causing you stress?";
          } else if (context.includes('achievement') || context.includes('success')) {
            botResponse = "That's wonderful! Professional achievements are worth celebrating. How does this success make you feel?";
          }
        } else if (context.includes('family') || context.includes('relationship')) {
          botResponse = "Relationships play a crucial role in our well-being. Would you like to explore these feelings further?";
        } else if (context.includes('anxiety') || context.includes('worried')) {
          botResponse = "I hear that you're feeling anxious. Let's break this down - what's the main concern that's causing these feelings?";
        } else if (context.includes('happy') || context.includes('excited')) {
          botResponse = "Your positive energy is wonderful! What's contributing to these good feelings?";
        } else if (context.includes('sad') || context.includes('depressed')) {
          botResponse = "I'm here to listen and support you. Can you tell me more about what's making you feel this way?";
        }

        const botMessage: Message = {
          id: crypto.randomUUID(),
          text: botResponse,
          sender: 'bot',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botMessage]);
      }, 1000);
    }

    setMessage('');
    setIsProcessing(true);
    setTimeout(() => setIsProcessing(false), 1000);
  };

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="bg-white rounded-3xl shadow-lg overflow-hidden">
        <div className="flex items-center p-4 border-b">
          <h2 className="font-semibold">
            {currentConversation?.topic || 'New Chat'}
          </h2>
        </div>

        <div ref={chatAreaRef} className="h-[500px] p-4 overflow-y-auto">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`mb-4 ${msg.sender === 'user' ? 'flex justify-end' : ''}`}
            >
              <div
                className={`rounded-lg p-4 max-w-[80%] ${
                  msg.sender === 'user' ? 'bg-[#BAE6F2]' : 'bg-gray-100'
                }`}
              >
                <p>{msg.text}</p>
                <span className="text-xs text-gray-500">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex gap-2 items-center text-gray-500">
              <div className="animate-bounce">●</div>
              <div className="animate-bounce [animation-delay:0.2s]">●</div>
              <div className="animate-bounce [animation-delay:0.4s]">●</div>
            </div>
          )}
        </div>

        <div className="p-4 border-t">
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Smile className="w-6 h-6 text-gray-500" />
            </button>
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Write your message..."
              className="flex-1 p-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-[#BAE6F2]"
            />
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Mic className="w-6 h-6 text-gray-500" />
            </button>
            <button 
              onClick={handleSendMessage}
              disabled={isProcessing}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <Send className="w-6 h-6 text-gray-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;